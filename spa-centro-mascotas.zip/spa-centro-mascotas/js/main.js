import { loadView } from './ui.js';
import { setupLoginForm, setupRegisterForm } from './auth.js';
import { renderDashboard } from './dashboard.js';

const routes = {
  '': () => loadView('landingView'),
  '#login': async () => {
    await loadView('loginView');
    setupLoginForm();
  },
  '#register': async () => {
    await loadView('registerView');
    setupRegisterForm();
  },
  '#dashboard': () => renderDashboard(),
};

function handleRoute() {
  const route = window.location.hash || '';
  const render = routes[route] || (() => loadView('404View'));
  render();
}

window.addEventListener('hashchange', handleRoute);
window.addEventListener('DOMContentLoaded', handleRoute);
