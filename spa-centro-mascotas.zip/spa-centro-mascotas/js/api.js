export async function login(email, password) {
  const res = await fetch(`http://localhost:3000/users?email=${email}`);
  const users = await res.json();
  const user = users.find(u => u.contrasena === password);
  if (!user) throw new Error('Login fallido');
  return user;
}
