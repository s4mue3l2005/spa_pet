import { login } from './api.js';
import { setCurrentUser } from './session.js';

export function setupLoginForm() {
  const form = document.getElementById('loginForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = form.email.value;
    const password = form.password.value;

    try {
      const user = await login(email, password);
      setCurrentUser(user);
      window.location.hash = '#dashboard';
    } catch (err) {
      alert("Credenciales inválidas");
    }
  });
}

export function setupRegisterForm() {
  const form = document.getElementById('registerForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {
      nombre: form.nombre.value,
      identidad: form.identidad.value,
      telefono: form.telefono.value,
      direccion: form.direccion.value,
      email: form.email.value,
      contrasena: form.contrasena.value,
      rolId: 2
    };
    try {
      await fetch('http://localhost:3000/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      alert('Registro exitoso');
      window.location.hash = '#login';
    } catch (err) {
      alert('Error al registrar usuario');
    }
  });
}
