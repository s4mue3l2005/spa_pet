import { login, logout, register } from './auth.js';
import { loadDashboard } from './dashboard.js';

// Cargar la página correspondiente según la ruta
export function loadPage(path) {
  const appDiv = document.getElementById('app');
  
  appDiv.classList.add('hidden');  // Aplicar la transición de ocultar la vista
  
  setTimeout(() => {
    switch(path) {
      case '/':
        appDiv.innerHTML = loadLanding();
        break;
      case '/login':
        appDiv.innerHTML = loadLogin();
        break;
      case '/register':
        appDiv.innerHTML = loadRegister();
        break;
      case '/dashboard':
        const currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser) {
          appDiv.innerHTML = loadDashboard(currentUser);
        } else {
          window.location.href = '/login';
        }
        break;
      default:
        appDiv.innerHTML = load404();
    }

    appDiv.classList.remove('hidden');  // Quitar la transición de ocultar
  }, 500);
}

// Funciones para cargar cada vista
function loadLanding() {
  return `
    <section>
      <h1>Bienvenido al Centro de Cuidado de Mascotas</h1>
      <nav>
        <ul>
          <li><a href="/login">Iniciar sesión</a></li>
          <li><a href="/register">Registrarse</a></li>
        </ul>
      </nav>
    </section>
  `;
}

function loadLogin() {
  return `
    <section>
      <h1>Iniciar sesión</h1>
      <form id="login-form">
        <input type="email" id="email" placeholder="Correo electrónico" required>
        <input type="password" id="password" placeholder="Contraseña" required>
        <button type="submit">Iniciar sesión</button>
      </form>
      <nav>
        <ul>
          <li><a href="/">Volver al inicio</a></li>
          <li><a href="/register">¿No tienes cuenta? Regístrate</a></li>
        </ul>
      </nav>
    </section>
  `;
}

function loadRegister() {
  return `
    <section>
      <h1>Registrarse</h1>
      <form id="register-form">
        <input type="text" id="name" placeholder="Nombre completo" required>
        <input type="email" id="email" placeholder="Correo electrónico" required>
        <input type="password" id="password" placeholder="Contraseña" required>
        <button type="submit">Registrarse</button>
      </form>
      <nav>
        <ul>
          <li><a href="/">Volver al inicio</a></li>
          <li><a href="/login">¿Ya tienes cuenta? Inicia sesión</a></li>
        </ul>
      </nav>
    </section>
  `;
}

function load404() {
  return `
    <section>
      <h1>404 - Página no encontrada</h1>
      <p>La página que buscas no existe.</p>
      <nav>
        <ul>
          <li><a href="/">Volver al inicio</a></li>
        </ul>
      </nav>
    </section>
  `;
}

// Añadir listeners a los formularios
document.addEventListener('DOMContentLoaded', () => {
  // Formulario de login
  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      login(email, password);
    });
  }

  // Formulario de registro
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      register(name, email, password);
    });
  }
});
