export function loadLanding() {
  return `
    <section>
      <header>
        <h1>Bienvenido al Centro de Cuidado de Mascotas</h1>
        <p>¡El lugar perfecto para cuidar a tu mascota mientras no estás en casa!</p>
      </header>
      <nav>
        <ul>
          <li><a href="/login">Iniciar sesión</a></li>
          <li><a href="/register">Registrarse</a></li>
        </ul>
      </nav>
    </section>
  `;
}

export function loadLogin() {
  return `
    <section>
      <header>
        <h1>Iniciar Sesión</h1>
      </header>
      <form id="login-form" aria-labelledby="login-form">
        <label for="email">Correo electrónico</label>
        <input type="email" id="email" placeholder="Email" required>
        
        <label for="password">Contraseña</label>
        <input type="password" id="password" placeholder="Contraseña" required>
        
        <button type="submit">Iniciar sesión</button>
      </form>
      <p>¿No tienes cuenta? <a href="/register">Regístrate aquí</a></p>
    </section>
  `;
}

export function loadRegister() {
  return `
    <section>
      <header>
        <h1>Registrarse</h1>
      </header>
      <form id="register-form" aria-labelledby="register-form">
        <label for="name">Nombre</label>
        <input type="text" id="name" placeholder="Nombre" required>
        
        <label for="email">Correo electrónico</label>
        <input type="email" id="email" placeholder="Email" required>
        
        <label for="password">Contraseña</label>
        <input type="password" id="password" placeholder="Contraseña" required>
        
        <button type="submit">Registrarse</button>
      </form>
      <p>¿Ya tienes cuenta? <a href="/login">Inicia sesión aquí</a></p>
    </section>
  `;
}

export function loadDashboard(currentUser) {
  return `
    <section>
      <header>
        <h1>Dashboard de ${currentUser.name}</h1>
      </header>
      <p>Bienvenido a tu panel de control. Aquí puedes gestionar a tus mascotas y estancias.</p>
      <nav>
        <ul>
          <li><a href="/pets">Ver Mascotas</a></li>
          <li><a href="/stays">Gestionar Estancias</a></li>
        </ul>
      </nav>
    </section>
  `;
}

export function load404() {
  return `
    <section>
      <header>
        <h1>Página no encontrada (404)</h1>
      </header>
      <p>Lo sentimos, la página que buscas no existe.</p>
    </section>
  `;
}
