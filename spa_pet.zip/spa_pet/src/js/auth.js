// Validación de formularios
export function validateLoginForm(email, password) {
  if (!email || !password) {
    alert("Por favor, complete todos los campos.");
    return false;
  }
  return true;
}

export function validateRegisterForm(name, email, password) {
  if (!name || !email || !password) {
    alert("Por favor, complete todos los campos.");
    return false;
  }
  if (password.length < 6) {
    alert("La contraseña debe tener al menos 6 caracteres.");
    return false;
  }
  return true;
}

// Login
export function login(email, password) {
  if (!validateLoginForm(email, password)) return;

  fetch('http://localhost:3000/users?email=' + email)
    .then(response => response.json())
    .then(users => {
      const user = users.find(u => u.email === email && u.password === password);
      if (user) {
        localStorage.setItem('currentUser', JSON.stringify(user));
        window.location.href = '/dashboard';
      } else {
        alert('Credenciales incorrectas');
      }
    });
}

// Registro
export function register(name, email, password) {
  if (!validateRegisterForm(name, email, password)) return;

  const user = {
    name, email, password, roleId: 2 // Rol 'customer'
  };

  fetch('http://localhost:3000/users', {
    method: 'POST',
    body: JSON.stringify(user),
    headers: { 'Content-Type': 'application/json' },
  })
    .then(response => response.json())
    .then(newUser => {
      localStorage.setItem('currentUser', JSON.stringify(newUser));
      window.location.href = '/dashboard';
    });
}

// Logout
export function logout() {
  localStorage.removeItem('currentUser');
  window.location.href = '/';
}
