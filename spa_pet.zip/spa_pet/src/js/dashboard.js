export function loadDashboard(currentUser) {
  if (!currentUser) {
    window.location.href = '/login';
    return;
  }

  if (currentUser.roleId === 2) {  // Cliente
    return loadCustomerDashboard(currentUser);
  }

  if (currentUser.roleId === 1) {  // Trabajador
    return loadWorkerDashboard(currentUser);
  }

  window.location.href = '/login';
}

function loadCustomerDashboard(currentUser) {
  return `
    <section>
      <header>
        <h1>Dashboard de ${currentUser.name}</h1>
      </header>
      <nav>
        <ul>
          <li><a href="/pets">Ver Mascotas</a></li>
        </ul>
      </nav>
    </section>
  `;
}

function loadWorkerDashboard(currentUser) {
  return `
    <section>
      <header>
        <h1>Dashboard de Trabajador - ${currentUser.name}</h1>
      </header>
      <nav>
        <ul>
          <li><a href="/pets">Ver Mascotas</a></li>
          <li><a href="/stays">Gestionar Estancias</a></li>
        </ul>
      </nav>
    </section>
  `;
}
